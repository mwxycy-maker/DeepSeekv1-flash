import bpy, math, os, random
from mathutils import Vector
OUT=os.path.dirname(os.path.abspath(__file__))
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for d in list(bpy.data.collections):
    if d.name != 'Collection': bpy.data.collections.remove(d)
base=bpy.data.collections.get('Collection'); base.name='01 • CAR / 可编辑车体'
fx=bpy.data.collections.new('02 • THRUST / 喷气效果'); bpy.context.scene.collection.children.link(fx)
studio=bpy.data.collections.new('03 • STUDIO / 灯光相机'); bpy.context.scene.collection.children.link(studio)
ref=bpy.data.collections.new('04 • REFERENCE / 原始概念图'); bpy.context.scene.collection.children.link(ref)
def move(o,c):
    for old in list(o.users_collection):old.objects.unlink(o)
    c.objects.link(o)
def mat(n,c,metal=0,rough=.3):
    m=bpy.data.materials.new(n);m.diffuse_color=(*c,1);m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
    return m
white=mat('Pearl white • 珍珠白车漆',(.78,.83,.9),.48,.21)
black=mat('Carbon • 碳纤维深灰',(.012,.018,.025),.5,.27)
glass=mat('Smoked glass • 深色车窗',(.016,.035,.055),.65,.14)
rubber=mat('Tire rubber • 轮胎',(.018,.021,.025),0,.7)
metal=mat('Machined alloy • 银灰轮毂',(.33,.39,.48),.85,.24)
brake=mat('Brake caliper • 制动卡钳',(.6,.035,.025),.5,.3)
def emissive(n,c,s):
    m=mat(n,c,.1,.25);p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Emission Color'].default_value=(*c,1);p.inputs['Emission Strength'].default_value=s;return m
led=emissive('Ice white LED',(.7,.88,1),4)
red=emissive('Rear red LED',(1,.012,.018),3)
def finish(o,n,m,bevel=0,smooth=False,c=base):
    o.name=n;move(o,c)
    if m:o.data.materials.append(m)
    if bevel:
        b=o.modifiers.new('Soft manufactured edges','BEVEL');b.width=bevel;b.segments=3
        o.modifiers.new('Weighted corner normals','WEIGHTED_NORMAL')
    if smooth and o.type=='MESH':
        for p in o.data.polygons:p.use_smooth=True
    return o
def mesh(n,v,f,m,bevel=0):
    d=bpy.data.meshes.new(n);d.from_pydata(v,[],f);d.update();o=bpy.data.objects.new(n,d);base.objects.link(o)
    bpy.context.view_layer.objects.active=o;o.select_set(True)
    bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT');o.select_set(False)
    return finish(o,n,m,bevel)
def box(n,loc,scale,m,b=.02):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.dimensions=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,n,m,b)
def cyl(n,loc,r,depth,m,axis='Y',verts=64):
    bpy.ops.mesh.primitive_cylinder_add(vertices=verts,radius=r,depth=depth,location=loc,rotation=(math.pi/2,0,0) if axis=='Y' else (0,0,0));return finish(bpy.context.object,n,m,.008,True)
def line(n,pts,m,r=.012):
    d=bpy.data.curves.new(n,'CURVE');d.dimensions='3D';d.bevel_depth=r;d.bevel_resolution=3;s=d.splines.new('POLY');s.points.add(len(pts)-1)
    for p,v in zip(s.points,pts):p.co=(*v,1)
    o=bpy.data.objects.new(n,d);base.objects.link(o);o.data.materials.append(m);return o
# Chassis loft: real solid geometry with open wheel arches.
sections=[(-2.48,.86,.72),(-2.12,1.02,.92),(-1.5,1.07,1.13),(-.72,1.04,1.13),(.25,1.02,1.10),(1.48,1.10,1.23),(2.13,1.04,1.15),(2.38,.94,.95)]
v=[]
for x,w,h in sections:
    v += [(x,-w*.9,.41),(x,-w,.60),(x,-w,h-.12),(x,-w*.7,h),(x,w*.7,h),(x,w,h-.12),(x,w,.60),(x,w*.9,.41)]
f=[tuple(reversed(range(8))),tuple(range((len(sections)-1)*8,len(sections)*8))]
for j in range(len(sections)-1):
    for k in range(8):f.append((j*8+k,j*8+(k+1)%8,(j+1)*8+(k+1)%8,(j+1)*8+k))
body=mesh('Body • 一体式楔形车身',v,f,white)
for x in [-1.47,1.47]:
    for side in [-1,1]:
        cutter=cyl('arch cutter',(x,side*1.15,.55),.555,.72,None)
        bpy.context.view_layer.objects.active=body;mod=body.modifiers.new('Wheel arch','BOOLEAN');mod.operation='DIFFERENCE';mod.object=cutter;bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(cutter,do_unlink=True)
b=body.modifiers.new('Paint edge highlights','BEVEL');b.width=.025;b.segments=3
body.modifiers.new('Body weighted normals','WEIGHTED_NORMAL')
box('Underbody carbon tray',(0,0,.43),(3.95,1.69,.12),black)
# Wide aero wheels, brakes and concentric details.
for x,ax in [(-1.47,'Front'),(1.47,'Rear')]:
    for s,side in [(-1,'L'),(1,'R')]:
        y=s*.99
        bpy.ops.mesh.primitive_torus_add(major_segments=80,minor_segments=20,location=(x,y,.55),rotation=(math.pi/2,0,0),major_radius=.405,minor_radius=.12)
        tire=finish(bpy.context.object,f'{ax} {side} • Tire',rubber,0,True);tire.scale.z=1.32
        cyl(f'{ax} {side} • Brake disc',(x,y,.55),.35,.15,metal)
        box(f'{ax} {side} • Caliper',(x+.22,s*1.055,.55),(.09,.1,.3),brake)
        cyl(f'{ax} {side} • Aero wheel',(x,s*1.135,.55),.365,.055,black)
        bpy.ops.mesh.primitive_torus_add(major_segments=80,minor_segments=10,location=(x,s*1.168,.55),rotation=(math.pi/2,0,0),major_radius=.348,minor_radius=.012)
        finish(bpy.context.object,f'{ax} {side} • Alloy rim edge',metal,0,True)
        for a in range(5):
            t=2*math.pi*a/5
            pts=[(x+.10*math.cos(t),s*1.17,.55+.10*math.sin(t)),(x+.32*math.cos(t+.16),s*1.17,.55+.32*math.sin(t+.16))]
            line(f'{ax} {side} • Aero spoke {a}',pts,metal,.023)
        cyl(f'{ax} {side} • Hub',(x,s*1.18,.55),.075,.018,metal)
        # Fine tread grooves on the shoulder.
        for k in range(48):
            a=k*2*math.pi/48
            pts=[(x+.521*math.cos(a),s*.94,.55+.521*math.sin(a)),(x+.524*math.cos(a+.025),s*1.02,.55+.524*math.sin(a+.025))]
            line(f'{ax} {side} • Tread {k:02}',pts,black,.004)
# Continuous low glass canopy.
cv=[(-.85,-.78,1.09),(-.85,.78,1.09),(-.08,-.64,1.67),(-.08,.64,1.67),(.76,-.61,1.66),(.76,.61,1.66),(1.42,-.8,1.12),(1.42,.8,1.12)]
mesh('Canopy • 前挡风与座舱',cv,[(0,1,3,2),(2,3,5,4),(4,5,7,6),(0,2,4,6),(1,7,5,3),(0,6,7,1)],glass,.045)
for s in [-1,1]:
    line('Window perimeter',[(x,s*y,z) for x,y,z in [(-.85,.78,1.10),(-.08,.64,1.68),(.76,.61,1.67),(1.42,.8,1.13)]],black,.028)
    line('B pillar',[(.53,s*.635,1.66),(.69,s*.79,1.13)],black,.025)
    # Swept white rear buttress.
    mesh('Rear shoulder sail',[(.73,s*.64,1.62),(1.62,s*.84,1.16),(1.31,s*1.0,1.13),(.96,s*.77,1.45)],[(0,1,2,3)],white,.015)
    line('Door shut line',[(-.77,s*1.037,.99),(-.88,s*1.046,.75),(-.66,s*1.041,.53),(.73,s*1.038,.53),(.93,s*1.05,.98)],black,.006)
    box('Flush door handle',(.38,s*1.045,1.025),(.23,.018,.028),black,.008)
    mesh('Side triangular intake',[(.62,s*1.052,.60),(1.01,s*1.075,1.04),(.95,s*1.079,.58)],[(0,1,2)],black,.01)
    line('Carbon rocker',[(-.94,s*1.047,.43),(.84,s*1.07,.43)],black,.047)
    # Narrow LED brows, following sharp hood corner.
    line('Headlight black housing',[(-2.46,s*.60,.728),(-2.20,s*.87,.86),(-1.91,s*.96,.94)],black,.052)
    line('Front DRL',[(-2.465,s*.61,.748),(-2.20,s*.876,.88),(-1.94,s*.964,.958)],led,.015)
    line('Hood crease',[(-2.2,s*.42,.92),(-1.55,s*.52,1.145),(-.87,s*.59,1.145)],black,.0035)
    # Small mirrors.
    line('Mirror stem',[(-.61,s*.83,1.17),(-.53,s*1.07,1.19)],black,.018)
    box('Mirror shell',(-.50,s*1.12,1.20),(.22,.16,.08),white,.035)
# Sculpted nose and rear fascia.
mesh('Front lower intake',[(-2.49,-.61,.45),(-2.49,.61,.45),(-2.49,.59,.66),(-2.49,-.59,.66)],[(0,1,2,3)],black,.015)
box('Front splitter',(-2.31,0,.405),(.48,1.88,.055),black,.025)
line('Rear lightbar',[(2.38,-.83,.92),(2.4,0,.95),(2.38,.83,.92)],red,.023)
box('Rear diffuser',(2.31,0,.49),(.21,1.58,.2),black,.025)
for y in [-.66,-.33,0,.33,.66]:box('Diffuser fin',(2.27,y,.42),(.4,.026,.20),black,.006)
for s in [-1,1]:
    support=box('Wing pylon',(1.93,s*.63,1.38),(.13,.055,.51),black,.01);support.rotation_euler.y=-.23
wing=box('Rear active wing',(2.01,0,1.65),(.40,2.14,.075),white,.035);wing.rotation_euler.y=.045
for s in [-1,1]:box('Wing endplate',(2.02,s*1.07,1.66),(.43,.035,.19),black,.015)
# Four independent downward thruster pods.
for x in [-.95,1.02]:
    for y in [-.71,.71]:
        cyl('Lift thruster • 喷气喷口',(x,y,.36),.135,.16,metal,'Z')
        cyl('Nozzle inner',(x,y,.27),.105,.015,black,'Z')
        bpy.ops.mesh.primitive_torus_add(major_radius=.11,minor_radius=.015,major_segments=40,minor_segments=8,location=(x,y,.27))
        finish(bpy.context.object,'Nozzle rim',metal,0,True)
# Volumetric white compressed-gas plumes: noise is multiplied by a smooth edge falloff.
vol=bpy.data.materials.new('Cold gas • 白色体积喷流');vol.use_nodes=True
nt=vol.node_tree;nt.nodes.clear();out=nt.nodes.new('ShaderNodeOutputMaterial');p=nt.nodes.new('ShaderNodeVolumePrincipled');p.inputs['Color'].default_value=(.8,.88,1,1);p.inputs['Anisotropy'].default_value=.2
tex=nt.nodes.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=7;tex.inputs['Detail'].default_value=3;tex.inputs['Roughness'].default_value=.7
coord=nt.nodes.new('ShaderNodeTexCoord');nt.links.new(coord.outputs['Generated'],tex.inputs['Vector'])
mult=nt.nodes.new('ShaderNodeMath');mult.operation='MULTIPLY';mult.inputs[1].default_value=1.8;nt.links.new(tex.outputs['Fac'],mult.inputs[0]);nt.links.new(mult.outputs[0],p.inputs['Density']);nt.links.new(p.outputs['Volume'],out.inputs['Volume'])
# Fade volume smoothly to zero at its bounds.
sub=nt.nodes.new('ShaderNodeVectorMath');sub.operation='SUBTRACT';sub.inputs[1].default_value=(.5,.5,.5);nt.links.new(coord.outputs['Generated'],sub.inputs[0])
length=nt.nodes.new('ShaderNodeVectorMath');length.operation='LENGTH';nt.links.new(sub.outputs['Vector'],length.inputs[0])
fade=nt.nodes.new('ShaderNodeMapRange');fade.clamp=True;fade.interpolation_type='SMOOTHERSTEP';fade.inputs['From Min'].default_value=.16;fade.inputs['From Max'].default_value=.51;fade.inputs['To Min'].default_value=1;fade.inputs['To Max'].default_value=0;nt.links.new(length.outputs['Value'],fade.inputs['Value'])
product=nt.nodes.new('ShaderNodeMath');product.operation='MULTIPLY';nt.links.new(mult.outputs[0],product.inputs[0]);nt.links.new(fade.outputs['Result'],product.inputs[1]);nt.links.new(product.outputs[0],p.inputs['Density'])
random.seed(7)
for x in [-.95,1.02]:
    for y in [-.71,.71]:
        bpy.ops.mesh.primitive_cone_add(vertices=48,radius1=.30,radius2=.065,depth=.94,location=(x,y,-.20));finish(bpy.context.object,'Jet core • 高速气柱',vol,0,False,fx)
        for k in range(5):
            bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,radius=1,location=(x+random.uniform(-.12,.12),y+random.uniform(-.12,.12),-.47-k*.105))
            o=bpy.context.object;o.scale=(.18+k*.06,.18+k*.06,.20);finish(o,'Vapor • 扩散雾化',vol,0,False,fx)
# Reference image is packed, hidden from render and viewport by default.
img=bpy.data.images.load('/Users/sniper/.codex/generated_images/01a153c0-ee36-7fb1-af7c-ccaf90e5939e/exec-52d134d8-c138-4188-aa52-76d5436e6fdb.png');img.pack()
o=bpy.data.objects.new('Concept reference • 参考图',None);o.empty_display_type='IMAGE';o.data=img;o.empty_display_size=6;ref.objects.link(o);o.hide_render=True;o.hide_viewport=True
# Neutral studio illumination with transparent environment.
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=64;scene.cycles.use_denoising=True
scene.world.color=(.22,.22,.22)
def area(n,loc,power,size,color):
    d=bpy.data.lights.new(n,'AREA');d.energy=power;d.shape='DISK';d.size=size;d.color=color;o=bpy.data.objects.new(n,d);studio.objects.link(o);o.location=loc;o.rotation_euler=(Vector((0,0,.7))-o.location).to_track_quat('-Z','Y').to_euler()
area('Large soft key',(-3,-4,6),1500,5,(.86,.93,1))
area('Warm rim',(3,3,4),1900,4,(1,.89,.72))
area('Front fill',(-4,3,2.5),1100,3,(.8,.88,1))
area('Side softbox',(1,-5,2.4),900,3,(1,1,1))
d=bpy.data.cameras.new('Camera');cam=bpy.data.objects.new('Camera • 主视角',d);studio.objects.link(cam);cam.location=(-7.4,8.6,2.9);target=Vector((0,0,.45));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=6.5;scene.camera=cam
scene.render.resolution_x=1500;scene.render.resolution_y=1100;scene.render.resolution_percentage=100;scene.render.film_transparent=True
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGBA';scene.render.filepath=os.path.join(OUT,'飞行跑车_3D预览.png')
scene.view_settings.view_transform='AgX';scene.unit_settings.system='METRIC'
scene['说明']='根据用户提供的 AI 概念图片制作的可编辑三维概念模型；不是 Tesla 官方 CAD。车身、轮胎、车窗、尾翼和喷嘴均为真实几何体。喷气为独立体积效果集合。'
for screen in bpy.data.screens:
    for a in screen.areas:
        if a.type=='VIEW_3D':
            a.spaces.active.region_3d.view_perspective='CAMERA';a.spaces.active.shading.type='MATERIAL';a.spaces.active.overlay.show_overlays=False
bpy.ops.object.select_all(action='DESELECT');body.select_set(True);bpy.context.view_layer.objects.active=body
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'飞行跑车_可编辑模型.blend'))
print('MODEL_SAVED',len([o for o in base.objects if o.type=='MESH']), 'mesh objects',flush=True)
bpy.ops.render.render(write_still=True)
print('RENDER_COMPLETE',flush=True)
